#include <iostream>
#include <cmath>
#include <stdlib.h>
#include <fstream>
#include <sstream>


class Perceptron {
public:
	Perceptron(int inp_dim = 0, int h_dims = 0, int* h_dims_ns = {}, int out_dims = 0) : inp_dim_(inp_dim), h_dims_(h_dims), h_vals(h_dims_ns), out_dims_(out_dims) {}
	void info() {
		std::cout << inp_dim_ << " " << h_dims_ << " " << out_dims_ << " ";
		for (int i = 0; i < h_dims_ - 1; i++)
			std::cout << h_vals[i] << " ";
		std::cout << h_vals[h_dims_ - 1];
	}
private:
	int inp_dim_ {0};
	int h_dims_{ 0 };
	int out_dims_{ 0 };
	int* h_vals = { 0 };
};