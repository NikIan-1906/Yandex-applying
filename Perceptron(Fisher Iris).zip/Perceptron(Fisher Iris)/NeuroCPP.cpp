﻿#include <iostream>
#include <cmath>
#include <stdlib.h>
#include <fstream>
#include <sstream>
#include "Perceptron.h"
using namespace std;

#define INPUT_DIM 4
#define H1_DIM 10
#define H2_DIM 10
#define OUT_DIM 3
#define ALPHA 0.000000001
#define NUM_EPOCHS 30000
unsigned long long int count_ = 0;
double dataset[150][2][INPUT_DIM] = {
{{5.1, 3.5, 1.4, 0.2}, 0},
{{4.9, 3.0, 1.4, 0.2}, 0},
{{4.7, 3.2, 1.3, 0.2}, 0},
{{4.6, 3.1, 1.5, 0.2}, 0},
{{5.0, 3.6, 1.4, 0.2}, 0},
{{5.4, 3.9, 1.7, 0.4}, 0},
{{4.6, 3.4, 1.4, 0.3}, 0},
{{5.0, 3.4, 1.5, 0.2}, 0},
{{4.4, 2.9, 1.4, 0.2}, 0},
{{4.9, 3.1, 1.5, 0.1}, 0},
{{5.4, 3.7, 1.5, 0.2}, 0},
{{4.8, 3.4, 1.6, 0.2}, 0},
{{4.8, 3.0, 1.4, 0.1}, 0},
{{4.3, 3.0, 1.1, 0.1}, 0},
{{5.8, 4.0, 1.2, 0.2}, 0},
{{5.7, 4.4, 1.5, 0.4}, 0},
{{5.4, 3.9, 1.3, 0.4}, 0},
{{5.1, 3.5, 1.4, 0.3}, 0},
{{5.7, 3.8, 1.7, 0.3}, 0},
{{5.1, 3.8, 1.5, 0.3}, 0},
{{5.4, 3.4, 1.7, 0.2}, 0},
{{5.1, 3.7, 1.5, 0.4}, 0},
{{4.6, 3.6, 1.0, 0.2}, 0},
{{5.1, 3.3, 1.7, 0.5}, 0},
{{4.8, 3.4, 1.9, 0.2}, 0},
{{5.0, 3.0, 1.6, 0.2}, 0},
{{5.0, 3.4, 1.6, 0.4}, 0},
{{5.2, 3.5, 1.5, 0.2}, 0},
{{5.2, 3.4, 1.4, 0.2}, 0},
{{4.7, 3.2, 1.6, 0.2}, 0},
{{4.8, 3.1, 1.6, 0.2}, 0},
{{5.4, 3.4, 1.5, 0.4}, 0},
{{5.2, 4.1, 1.5, 0.1}, 0},
{{5.5, 4.2, 1.4, 0.2}, 0},
{{4.9, 3.1, 1.5, 0.2}, 0},
{{5.0, 3.2, 1.2, 0.2}, 0},
{{5.5, 3.5, 1.3, 0.2}, 0},
{{4.9, 3.6, 1.4, 0.1}, 0},
{{4.4, 3.0, 1.3, 0.2}, 0},
{{5.1, 3.4, 1.5, 0.2}, 0},
{{5.0, 3.5, 1.3, 0.3}, 0},
{{4.5, 2.3, 1.3, 0.3}, 0},
{{4.4, 3.2, 1.3, 0.2}, 0},
{{5.0, 3.5, 1.6, 0.6}, 0},
{{5.1, 3.8, 1.9, 0.4}, 0},
{{4.8, 3.0, 1.4, 0.3}, 0},
{{5.1, 3.8, 1.6, 0.2}, 0},
{{4.6, 3.2, 1.4, 0.2}, 0},
{{5.3, 3.7, 1.5, 0.2}, 0},
{{5.0, 3.3, 1.4, 0.2}, 0},
{{7.0, 3.2, 4.7, 1.4}, 1},
{{6.4, 3.2, 4.5, 1.5}, 1},
{{6.9, 3.1, 4.9, 1.5}, 1},
{{5.5, 2.3, 4.0, 1.3}, 1},
{{6.5, 2.8, 4.6, 1.5}, 1},
{{5.7, 2.8, 4.5, 1.3}, 1},
{{6.3, 3.3, 4.7, 1.6}, 1},
{{4.9, 2.4, 3.3, 1.0}, 1},
{{6.6, 2.9, 4.6, 1.3}, 1},
{{5.2, 2.7, 3.9, 1.4}, 1},
{{5.0, 2.0, 3.5, 1.0}, 1},
{{5.9, 3.0, 4.2, 1.5}, 1},
{{6.0, 2.2, 4.0, 1.0}, 1},
{{6.1, 2.9, 4.7, 1.4}, 1},
{{5.6, 2.9, 3.6, 1.3}, 1},
{{6.7, 3.1, 4.4, 1.4}, 1},
{{5.6, 3.0, 4.5, 1.5}, 1},
{{5.8, 2.7, 4.1, 1.0}, 1},
{{6.2, 2.2, 4.5, 1.5}, 1},
{{5.6, 2.5, 3.9, 1.1}, 1},
{{5.9, 3.2, 4.8, 1.8}, 1},
{{6.1, 2.8, 4.0, 1.3}, 1},
{{6.3, 2.5, 4.9, 1.5}, 1},
{{6.1, 2.8, 4.7, 1.2}, 1},
{{6.4, 2.9, 4.3, 1.3}, 1},
{{6.6, 3.0, 4.4, 1.4}, 1},
{{6.8, 2.8, 4.8, 1.4}, 1},
{{6.7, 3.0, 5.0, 1.7}, 1},
{{6.0, 2.9, 4.5, 1.5}, 1},
{{5.7, 2.6, 3.5, 1.0}, 1},
{{5.5, 2.4, 3.8, 1.1}, 1},
{{5.5, 2.4, 3.7, 1.0}, 1},
{{5.8, 2.7, 3.9, 1.2}, 1},
{{6.0, 2.7, 5.1, 1.6}, 1},
{{5.4, 3.0, 4.5, 1.5}, 1},
{{6.0, 3.4, 4.5, 1.6}, 1},
{{6.7, 3.1, 4.7, 1.5}, 1},
{{6.3, 2.3, 4.4, 1.3}, 1},
{{5.6, 3.0, 4.1, 1.3}, 1},
{{5.5, 2.5, 4.0, 1.3}, 1},
{{5.5, 2.6, 4.4, 1.2}, 1},
{{6.1, 3.0, 4.6, 1.4}, 1},
{{5.8, 2.6, 4.0, 1.2}, 1},
{{5.0, 2.3, 3.3, 1.0}, 1},
{{5.6, 2.7, 4.2, 1.3}, 1},
{{5.7, 3.0, 4.2, 1.2}, 1},
{{5.7, 2.9, 4.2, 1.3}, 1},
{{6.2, 2.9, 4.3, 1.3}, 1},
{{5.1, 2.5, 3.0, 1.1}, 1},
{{5.7, 2.8, 4.1, 1.3}, 1},
{{6.3, 3.3, 6.0, 2.5}, 2},
{{5.8, 2.7, 5.1, 1.9}, 2},
{{7.1, 3.0, 5.9, 2.1}, 2},
{{6.3, 2.9, 5.6, 1.8}, 2},
{{6.5, 3.0, 5.8, 2.2}, 2},
{{7.6, 3.0, 6.6, 2.1}, 2},
{{4.9, 2.5, 4.5, 1.7}, 2},
{{7.3, 2.9, 6.3, 1.8}, 2},
{{6.7, 2.5, 5.8, 1.8}, 2},
{{7.2, 3.6, 6.1, 2.5}, 2},
{{6.5, 3.2, 5.1, 2.0}, 2},
{{6.4, 2.7, 5.3, 1.9}, 2},
{{6.8, 3.0, 5.5, 2.1}, 2},
{{5.7, 2.5, 5.0, 2.0}, 2},
{{5.8, 2.8, 5.1, 2.4}, 2},
{{6.4, 3.2, 5.3, 2.3}, 2},
{{6.5, 3.0, 5.5, 1.8}, 2},
{{7.7, 3.8, 6.7, 2.2}, 2},
{{7.7, 2.6, 6.9, 2.3}, 2},
{{6.0, 2.2, 5.0, 1.5}, 2},
{{6.9, 3.2, 5.7, 2.3}, 2},
{{5.6, 2.8, 4.9, 2.0}, 2},
{{7.7, 2.8, 6.7, 2.0}, 2},
{{6.3, 2.7, 4.9, 1.8}, 2},
{{6.7, 3.3, 5.7, 2.1}, 2},
{{7.2, 3.2, 6.0, 1.8}, 2},
{{6.2, 2.8, 4.8, 1.8}, 2},
{{6.1, 3.0, 4.9, 1.8}, 2},
{{6.4, 2.8, 5.6, 2.1}, 2},
{{7.2, 3.0, 5.8, 1.6}, 2},
{{7.4, 2.8, 6.1, 1.9}, 2},
{{7.9, 3.8, 6.4, 2.0}, 2},
{{6.4, 2.8, 5.6, 2.2}, 2},
{{6.3, 2.8, 5.1, 1.5}, 2},
{{6.1, 2.6, 5.6, 1.4}, 2},
{{7.7, 3.0, 6.1, 2.3}, 2},
{{6.3, 3.4, 5.6, 2.4}, 2},
{{6.4, 3.1, 5.5, 1.8}, 2},
{{6.0, 3.0, 4.8, 1.8}, 2},
{{6.9, 3.1, 5.4, 2.1}, 2},
{{6.7, 3.1, 5.6, 2.4}, 2},
{{6.9, 3.1, 5.1, 2.3}, 2},
{{5.8, 2.7, 5.1, 1.9}, 2},
{{6.8, 3.2, 5.9, 2.3}, 2},
{{6.7, 3.3, 5.7, 2.5}, 2},
{{6.7, 3.0, 5.2, 2.3}, 2},
{{6.3, 2.5, 5.0, 1.9}, 2},
{{6.5, 3.0, 5.2, 2.0}, 2},
{{6.2, 3.4, 5.4, 2.3}, 2},
{{5.9, 3.0, 5.1, 1.8}, 2}
};


double W1[INPUT_DIM][H1_DIM] = {
{0.473195, -0.109774, -0.46736, -0.219746, 0.622497, 0.790441, -0.0898151, 0.647054, 0.418009, -0.45075},
{1.00925, -0.0476511, -0.0620688, -0.266779, -0.00856399, 0.11914, -0.25896, 0.163109, -0.358266, 0.377052},
{-0.843864, 0.690251, 0.429052, 0.137934, 0.523932, -0.285596, -0.177728, -0.641072, 0.221475, 0.465354},
{-0.867113, 0.321767, 0.198084, -0.317292, 0.588291, -0.614576, -0.427688, -0.699857, -0.0756487, -0.331869}
};
double b1[1][H1_DIM] = { {0.518488, 0.273018, -0.11646, -0.105817, 0.243322, 0.55139, -0.253975, 0.478715, -0.359254, -0.186395} };
double W2[H1_DIM][H2_DIM] = {
{1.14369, 0.887214, -0.462025, 0.318632, -0.225361, -0.324689, 0.0435596, -0.517653, -0.250773, 0.29105},
{-0.40461, -0.359091, 0.294271, 0.164207, 0.0938044, 0.462503, -0.284167, 0.136591, 0.0573382, -0.265186},
{0.00769919, -0.00151086, 0.112483, -0.0873989, 0.0430191, -0.190768, 0.0468988, 0.0761456, 0.263372, -0.00749804},
{-0.0322115, 0.124661, 0.174642, 0.23831, 0.0181946, 0.246852, 0.12315, -0.0634833, -0.0820284, -0.240595},
{-0.142849, -0.028193, 0.537912, -0.240511, -0.199384, 0.458208, -0.0262357, 0.567532, -0.106259, -0.272365},
{0.873471, 0.495579, 0.0864758, 0.379923, -0.210987, 0.112621, -0.284828, 0.133236, -0.140546, -0.170425},
{0.163684, 0.2497, -0.0770664, -0.113829, 0.0994986, -0.0661742, -0.153713, -0.194764, -0.097546, -0.151597},
{0.736826, 0.636859, -0.310204, 0.122771, -0.115388, -0.546381, -0.099989, -0.1137, -0.0466589, -0.0467248},
{-0.0810434, -0.127136, 0.331442, -0.0427103, 0.0970181, 0.231569, -0.23018, -0.0857494, -0.0648053, -0.180856},
{0.308787, 0.0608808, -0.263327, -0.260913, 0.0840999, 0.182331, -0.189112, -0.0711212, -0.0314294, 0.0313241}
};
double b2[1][H2_DIM] = { {0.189121, 0.302938, 0.278133, 0.288829, 0.21683, -0.015886, 0.137298, 0.0202663, -0.204736, 0.203871} };
double W3[H2_DIM][OUT_DIM] = {
{0.863804, 0.495753, -1.32836},
{0.755148, 0.451356, -0.803905},
{-0.812049, 0.366497, 0.336982},
{0.100312, 0.0178292, -0.476533},
{-0.233606, -0.10504, 0.103765},
{-0.510157, -0.0987034, 0.641916},
{-0.00626841, -0.152109, -0.12697},
{-0.360286, 0.215301, 0.596839},
{-0.121858, 0.134653, 0.312003},
{0.218474, 0.214736, 0.314276}
};
double b3[1][OUT_DIM] = { {0.30826, 0.186425, 0.133857} };



double x[1][INPUT_DIM] = { {5.1, 3.5, 1.4, 0.2} };
double t1[1][H1_DIM];
double h1[1][H1_DIM];
double t2[1][H2_DIM];
double h2[1][H2_DIM];
double t3[1][OUT_DIM];
double z[1][OUT_DIM];



double round_n(double integer, int n) {
    return (double)round(integer * pow(10, n)) / pow(10, n);
}
double string_to_double(const string s)
{
    int str_len = s.length();
    char* digits = new char[str_len];
    int f = s[0] == '-';
    int dot_ = 0;
    double num = 0;
    for (int i = f; i < str_len - 1; ++i) {
        if (s[i] == '.') {
            dot_ = i;
            break;
        }
    }
    for (int i = f; i < str_len - 1; ++i) {
        if (i >= dot_)
            digits[i] = s[i + 1];
        else
            digits[i] = s[i];
    }
    for (int i = f; i < str_len - 1; i++) {
        int n = digits[i]-48;
        num += (n * pow(10, dot_ - i-1));
    }
    num = round_n(num, str_len - dot_);
    if (f == 0)
        return num;
    else
        return -num;
}
double random(int min, int max, int n=6) {
    return round_n((double)(rand()) / RAND_MAX * (max - min), n);
}
double **transpose(double **matrix, int rows, int columns)
{
    double** m_res = new double* [columns];
    for (int i = 0; i < columns; i++) {
        m_res[i] = new double[rows];
    }
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            m_res[j][i] = matrix[i][j];
        }
    }
    return m_res;
    for (int i = 0; i < columns; i++) {
        delete[] m_res[i];
    }
    delete[] m_res;
}
double **relu(double **Arr, int arr_len) {
    double** rtn = new double*[1];
    rtn[0] = new double[arr_len];
    for (int i = 0; i < arr_len; i++) {
        if (Arr[0][i] > 0.0) {
            rtn[0][i] = Arr[0][i];
        }
        else {
            rtn[0][i] = 0;
        }
    }
    return rtn;
    delete[] rtn[0];
    delete[] rtn;
}
double **matrix_multiply(const int M, const int N, const int K, double** m1, double** m2) {
    double** m_res = new double*[M];
    for (int i = 0; i < M; i++) {
        m_res[i] = new double[K];
    }
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < K; j++) {
            m_res[i][j] = 0;
        }
    }
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < K; j++) {
            double sum = 0;
            for (int n = 0; n < N; ++n) {
                sum += m1[i][n] * m2[n][j];
            }
            m_res[i][j] = sum;
        }
    }

    return m_res;
    for (int i = 0; i < M; i++) {
        delete[] m_res[i];
    }
    delete[] m_res;
}
double **softmax(double **t, int t_len) {
    double** z_1 = new double* [1];
    z_1[0] = new double[t_len];
    double sum_t = 0;
    for (int i = 0; i < t_len; i++) {
        z_1[0][i] = 0;
        sum_t += exp(t[0][i]);
    }
    for (int i = 0; i < t_len; i++) {
        z_1[0][i] = exp(t[0][i]) / sum_t;
    }
    
    return z_1;
    delete[] z_1[0];
    delete[] z_1;
}
double **relu_deriv(double** t, int t_len) {
    double** res = new double* [1];
    res[0] = new double[t_len];
    for (int i = 0; i < t_len; i++) {
        if (t[0][i] >= 0.0) {
            res[0][i] = 1;
        }
        else {
            res[0][i] = 0;
        }
    }
    return res;
}
double **rand_arr(int n, int m) {
    double** arr = new double* [n];
    for (int i = 0; i < n; ++i)
        arr[i] = new double[m];
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < m; ++j)
            arr[i][j] = random(0, 1);
    return arr;
}
void save_weights() {
    ofstream fout;
    fout.open("W1.txt");
    for (int i = 0; i < INPUT_DIM; i++) {
        for (int j = 0; j < H1_DIM; j++) {
            fout << W1[i][j];
            fout << " ";
        }
    }
    fout << "}";
    fout.close();
    fout.open("W2.txt");
    for (int i = 0; i < H1_DIM; i++) {
        for (int j = 0; j < H2_DIM; j++) {
            fout << W2[i][j];
            fout << " ";
        }
    }
    fout << "}";
    fout.close();
    fout.open("W3.txt");
    for (int i = 0; i < H2_DIM; i++) {
        for (int j = 0; j < OUT_DIM; j++) {
            fout << W3[i][j];
            fout << " ";
        }
    }
    fout << "}";
    fout.close();
    fout.open("b1.txt");
    for (int i = 0; i < H1_DIM; i++) {
        fout << b1[0][i];
        fout << " ";
    }
    fout << "}";
    fout.close();
    fout.open("b2.txt");
    for (int i = 0; i < H2_DIM; i++) {
        fout << b2[0][i];
        fout << " ";
    }
    fout << "}";
    fout.close();
    fout.open("b3.txt");
    for (int i = 0; i < OUT_DIM; i++) {
        fout << b3[0][i];
        fout << " ";
    }
    fout << "}";
    fout.close();
}
void get_weights() {
    ifstream fin;
    fin.open("W1.txt");
    unsigned long long FILE_LENGTH = 0;
    for (FILE_LENGTH = 0; fin.peek() != EOF; FILE_LENGTH++) {
        fin.get();
    }
    fin.seekg(0);
    char* text = new char[FILE_LENGTH];
    for (unsigned long long i = 0; fin.peek() != EOF; i++) {
        text[i] = fin.get();
    }
    fin.close();
    double* list = new double[INPUT_DIM * H1_DIM];
    for (int i = 0; i < INPUT_DIM * H1_DIM; i++)
        list[i] = 0;
    int c = 0;
    string s;
    for (unsigned long long i = 0; i < FILE_LENGTH and text[i] != '}'; i++) {
        if (text[i] != ' ') {
            s = s + text[i];
        }
        else {
            list[c] = string_to_double(s);
            c += 1;
            s = "";
        }
    }
    s = "";
    for (int i = 0; i < INPUT_DIM; ++i) {
        for (int j = 0; j < H1_DIM; ++j) {
            ;
            W1[i][j] = list[i * H1_DIM + j];
        }
    }
    delete[] list;
    fin.open("W2.txt");
    FILE_LENGTH = 0;
    for (FILE_LENGTH = 0; fin.peek() != EOF; FILE_LENGTH++) {
        fin.get();
    }
    fin.seekg(0);
    text = new char[FILE_LENGTH];
    for (unsigned long long i = 0; fin.peek() != EOF; i++) {
        text[i] = fin.get();
    }
    fin.close();
    list = new double[H1_DIM * H2_DIM];
    for (int i = 0; i < H1_DIM * H2_DIM; i++)
        list[i] = 0;
    c = 0;
    for (unsigned long long i = 0; i < FILE_LENGTH and text[i] != '}'; i++) {
        if (text[i] != ' ') {
            s = s + text[i];
        }
        else {
            list[c] = string_to_double(s);
            c += 1;
            s = "";
        }
    }
    s = "";
    for (int i = 0; i < H1_DIM; ++i) {
        for (int j = 0; j < H2_DIM; ++j) {
            ;
            W2[i][j] = list[i * H2_DIM + j];
        }
    }
    delete[] list;
    fin.open("W3.txt");
    FILE_LENGTH = 0;
    for (FILE_LENGTH = 0; fin.peek() != EOF; FILE_LENGTH++) {
        fin.get();
    }
    fin.seekg(0);
    text = new char[FILE_LENGTH];
    for (unsigned long long i = 0; fin.peek() != EOF; i++) {
        text[i] = fin.get();
    }
    fin.close();
    list = new double[H2_DIM * OUT_DIM];
    for (int i = 0; i < H2_DIM * OUT_DIM; i++)
        list[i] = 0;
    c = 0;
    for (unsigned long long i = 0; i < FILE_LENGTH and text[i] != '}'; i++) {
        if (text[i] != ' ') {
            s = s + text[i];
        }
        else {
            list[c] = string_to_double(s);
            c += 1;
            s = "";
        }
    }
    for (int i = 0; i < H2_DIM; ++i) {
        for (int j = 0; j < OUT_DIM; ++j) {
            ;
            W3[i][j] = list[i * OUT_DIM + j];
        }
    }
    delete[] list;
    fin.open("b2.txt");
    FILE_LENGTH = 0;
    for (FILE_LENGTH = 0; fin.peek() != EOF; FILE_LENGTH++) {
        fin.get();
    }
    fin.seekg(0);
    text = new char[FILE_LENGTH];
    for (unsigned long long i = 0; fin.peek() != EOF; i++) {
        text[i] = fin.get();
    }
    fin.close();
    list = new double[H2_DIM];
    for (int i = 0; i < H2_DIM; i++)
        list[i] = 0;
    c = 0;
    for (unsigned long long i = 0; i < FILE_LENGTH and text[i] != '}'; i++) {
        if (text[i] != ' ') {
            s = s + text[i];
        }
        else {
            list[c] = string_to_double(s);
            c += 1;
            s = "";
        }
    }
    for (int j = 0; j < H2_DIM; ++j) {
        b2[0][j] = list[j];
    }
    delete[] list;
    fin.open("b3.txt");
    FILE_LENGTH = 0;
    for (FILE_LENGTH = 0; fin.peek() != EOF; FILE_LENGTH++) {
        fin.get();
    }
    fin.seekg(0);
    text = new char[FILE_LENGTH];
    for (unsigned long long i = 0; fin.peek() != EOF; i++) {
        text[i] = fin.get();
    }
    fin.close();
    list = new double[OUT_DIM];
    for (int i = 0; i < OUT_DIM; i++)
        list[i] = 0;
    c = 0;
    for (unsigned long long i = 0; i < FILE_LENGTH and text[i] != '}'; i++) {
        if (text[i] != ' ') {
            s = s + text[i];
        }
        else {
            list[c] = string_to_double(s);
            c += 1;
            s = "";
        }
    }
    for (int j = 0; j < OUT_DIM; ++j) {
        b3[0][j] = list[j];
    }
    delete[] list;
    fin.open("b1.txt");
    FILE_LENGTH = 0;
    for (FILE_LENGTH = 0; fin.peek() != EOF; FILE_LENGTH++) {
        fin.get();
    }
    fin.seekg(0);
    text = new char[FILE_LENGTH];
    for (unsigned long long i = 0; fin.peek() != EOF; i++) {
        text[i] = fin.get();
    }
    fin.close();
    list = new double[H1_DIM];
    for (int i = 0; i < H1_DIM; i++)
        list[i] = 0;
    c = 0;
    for (unsigned long long i = 0; i < FILE_LENGTH and text[i] != '}'; i++) {
        if (text[i] != ' ') {
            s = s + text[i];
        }
        else {
            list[c] = string_to_double(s);
            c += 1;
            s = "";
        }
    }
    for (int j = 0; j < H1_DIM; ++j) {
        b1[0][j] = list[j];
    }
    delete[] list;
}
void learn_backprop() {
    unsigned long long int count_ = 0;
    double** W_1 = new double* [INPUT_DIM];
    for (int i = 0; i < INPUT_DIM; i++) {
        W_1[i] = new double[H1_DIM];
    }
    double** W_2 = new double* [H1_DIM];
    for (int i = 0; i < H1_DIM; i++) {
        W_2[i] = new double[H2_DIM];
    }
    double** W_3 = new double* [H2_DIM];
    for (int i = 0; i < H2_DIM; i++) {
        W_3[i] = new double[OUT_DIM];
    }
    double** b_1 = new double* [1];
    b_1[0] = new double[H1_DIM];
    double** b_2 = new double* [1];
    b_2[0] = new double[H2_DIM];
    double** b_3 = new double* [1];
    b_3[0] = new double[OUT_DIM];
    for (int i = 0; i < INPUT_DIM; i++)
        for (int j = 0; j < H1_DIM; j++)
            W_1[i][j] = W1[i][j];
    for (int i = 0; i < H1_DIM; i++)
        for (int j = 0; j < H2_DIM; j++)
            W_2[i][j] = W2[i][j];
    for (int i = 0; i < H2_DIM; i++)
        for (int j = 0; j < OUT_DIM; j++)
            W_3[i][j] = W3[i][j];
    for (int j = 0; j < H1_DIM; j++)
        b_1[0][j] = b1[0][j];
    for (int j = 0; j < H2_DIM; j++)
        b_2[0][j] = b2[0][j];
    for (int j = 0; j < OUT_DIM; j++)
        b_3[0][j] = b3[0][j];


    double** x_ = new double* [1];
    x_[0] = new double[INPUT_DIM];
    double** t_1 = new double* [1];
    t_1[0] = new double[H1_DIM];
    double** h_1 = new double* [1];
    h_1[0] = new double[H1_DIM];
    double** t_2 = new double* [1];
    t_2[0] = new double[H2_DIM];
    double** h_2 = new double* [1];
    h_2[0] = new double[H2_DIM];
    double** t_3 = new double* [1];
    t_3[0] = new double[OUT_DIM];
    double** z_ = new double* [1];
    z_[0] = new double[OUT_DIM];
    for (int i = 0; i < INPUT_DIM; i++)
        for (int j = 0; j < H1_DIM; j++)
            W_1[i][j] = W1[i][j];
    for (int j = 0; j < H1_DIM; j++)
        b_1[0][j] = b1[0][j];
    for (int i = 0; i < H1_DIM; i++)
        for (int j = 0; j < H2_DIM; j++)
            W_2[i][j] = W2[i][j];
    for (int j = 0; j < H2_DIM; j++)
        b_2[0][j] = b2[0][j];
    for (int i = 0; i < H2_DIM; i++)
        for (int j = 0; j < OUT_DIM; j++)
            W_3[i][j] = W3[i][j];
    for (int j = 0; j < OUT_DIM; j++)
        b_3[0][j] = b3[0][j];
    do {
        cout << count_ << "\n";
        for (int R = 0; R < 150; R++) {
            x_[0] = dataset[R][0];
            int y_ = dataset[R][1][0];
            //predict
            double** xW = new double* [1];
            xW[0] = new double[H1_DIM];
            xW = matrix_multiply(1, INPUT_DIM, H1_DIM, x_, W_1);
            for (int i = 0; i < H1_DIM; i++)
                t_1[0][i] = xW[0][i] + b_1[0][i];
            h_1 = relu(t_1, H1_DIM);
            xW = matrix_multiply(1, H1_DIM, H2_DIM, h_1, W_2);
            for (int i = 0; i < H2_DIM; i++)
                t_2[0][i] = xW[0][i] + b_2[0][i];
            h_2 = relu(t_2, H2_DIM);
            xW = matrix_multiply(1, H2_DIM, OUT_DIM, h_2, W_3);
            for (int i = 0; i < OUT_DIM; i++)
                t_3[0][i] = xW[0][i] + b_3[0][i];
            z_ = softmax(t_3, OUT_DIM);
            //error
            double y_full[OUT_DIM] = { 0, 0, 0 };
            y_full[y_] = 1;

            double** de_dt3 = new double* [1];
            de_dt3[0] = new double[OUT_DIM];
            for (int i = 0; i < OUT_DIM; i++) {
                de_dt3[0][i] = z_[0][i] - y_full[i];
            }
            double** h2_t = transpose(h_2, 1, H2_DIM);

            double** de_dW3 = matrix_multiply(H2_DIM, 1, OUT_DIM, h2_t, de_dt3);
            double** de_db3 = de_dt3;
            double** W3_t = transpose(W_3, H2_DIM, OUT_DIM);
            double** de_dh2 = matrix_multiply(1, OUT_DIM, H2_DIM, de_dt3, W3_t);
            double** de_dt2 = new double* [1];
            de_dt2[0] = new double[H2_DIM];
            double** drv_t_2 = relu_deriv(t_2, H2_DIM);
            for (int i = 0; i < H2_DIM; i++) {
                de_dt2[0][i] = de_dh2[0][i] * drv_t_2[0][i];
            }
            double** h1_t = transpose(h_1, 1, H1_DIM);

            double** de_dW2 = matrix_multiply(H1_DIM, 1, H2_DIM, h1_t, de_dt2);
            double** de_db2 = de_dt2;
            double** W2_t = transpose(W_2, H1_DIM, H2_DIM);
            double** de_dh1 = matrix_multiply(1, H2_DIM, H1_DIM, de_dt2, W2_t);
            double** de_dt1 = new double* [1];
            de_dt1[0] = new double[H2_DIM];
            double** drv_t_1 = relu_deriv(t_1, H2_DIM);
            for (int i = 0; i < H2_DIM; i++) {
                de_dt1[0][i] = de_dh1[0][i] * drv_t_1[0][i];
            }
            double** x_t = transpose(x_, 1, INPUT_DIM);

            double** de_dW1 = matrix_multiply(INPUT_DIM, 1, H1_DIM, x_t, de_dt1);
            double** de_db1 = de_dt1;
            //learn
            for (int i = 0; i < INPUT_DIM; i++)
                for (int j = 0; j < H1_DIM; j++)
                    W_1[i][j] = W_1[i][j] - (ALPHA * de_dW1[i][j]);
            for (int j = 0; j < H1_DIM; j++)
                b_1[0][j] = b_1[0][j] - (ALPHA * de_db1[0][j]);
            for (int i = 0; i < H1_DIM; i++)
                for (int j = 0; j < H2_DIM; j++)
                    W_2[i][j] = W_2[i][j] - (ALPHA * de_dW2[i][j]);
            for (int j = 0; j < H2_DIM; j++)
                b_2[0][j] = b_2[0][j] - (ALPHA * de_db2[0][j]);
            for (int i = 0; i < H2_DIM; i++)
                for (int j = 0; j < OUT_DIM; j++)
                    W_3[i][j] = W_3[i][j] - (ALPHA * de_dW3[i][j]);
            for (int j = 0; j < OUT_DIM; j++)
                b_3[0][j] = b_3[0][j] - (ALPHA * de_db3[0][j]);
        }
        count_ += 1;
    } while (count_ < NUM_EPOCHS);
    cout << "\n\n\n{{";
    for (int i = 0; i < INPUT_DIM; i++) {
        for (int j = 0; j < H1_DIM; j++) {
            W1[i][j] = W_1[i][j];
            cout << W1[i][j] << ", ";
        }
        cout << "}\n{";
    }
    cout << "}}\n{{";
    for (int i = 0; i < H1_DIM; i++) {
        for (int j = 0; j < H2_DIM; j++) {
            W2[i][j] = W_2[i][j];
            cout << W2[i][j] << ", ";
        }
        cout << "}\n{";
    }
    cout << "}}\n{{";
    for (int i = 0; i < H2_DIM; i++) {
        for (int j = 0; j < OUT_DIM; j++) {
            W3[i][j] = W_3[i][j];
            cout << W3[i][j] << ", ";
        }
        cout << "}\n{";
    }
    cout << "}}\n{{";
    for (int j = 0; j < H1_DIM; j++) {
        b1[0][j] = b_1[0][j];
        cout << b1[0][j] << ", ";
    }
    cout << "}}\n{{";
    for (int j = 0; j < H2_DIM; j++) {
        b2[0][j] = b_2[0][j];
        cout << b2[0][j] << ", ";
    }
    cout << "}}\n{{";
    for (int j = 0; j < OUT_DIM; j++) {
        b3[0][j] = b_3[0][j];
        cout << b3[0][j] << ", ";
    }
    cout << "}}";
}


int main() {
    int _[2] = { 2, 3 };
    Perceptron p(4, 2, _, 4);
    p.info();
}

