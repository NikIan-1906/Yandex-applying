// Basic algorythms

#include "BMP.h"
#include <iostream>
#include <fstream>
#include <cmath>

#define PI 3,1415926535

using namespace std;

int mono_pix(int pix[3]) {
	int x = (0.2125 * pix[0]) + (0.7154 * pix[1]) + (0.0721 * pix[2]);
	if (x < 0)
		x = 0;
	else if (x > 255)
		x = 255;
	return x;
}

void merge(int list[], int start, int end, int mid)
{
	int* mergedList = new int[end + 1];
	int i, j, k;
	i = start;
	k = start;
	j = mid + 1;

	while (i <= mid && j <= end) {
		if (list[i] < list[j]) {
			mergedList[k] = list[i];
			k++;
			i++;
		}
		else {
			mergedList[k] = list[j];
			k++;
			j++;
		}
	}

	while (i <= mid) {
		mergedList[k] = list[i];
		k++;
		i++;
	}

	while (j <= end) {
		mergedList[k] = list[j];
		k++;
		j++;
	}

	for (i = start; i < k; i++) {
		list[i] = mergedList[i];
	}
}

void mergeSort(int list[], int start, int end)
{
	int mid;
	if (start < end) {

		mid = (start + end) / 2;
		mergeSort(list, start, mid);
		mergeSort(list, mid + 1, end);
		merge(list, start, end, mid);
	}
}

int*** BMPread(const char* fname_, int& m, int& n) {
	BMP bmp(fname_);
	bmp.read(fname_);
	n = bmp.bmp_info_header.height;
	m = bmp.bmp_info_header.width;
	int k = 3;
	int*** matrix = new int** [n];
	for (int i = 0; i < n; i++) {
		matrix[i] = new int* [m];
		for (int j = 0; j < m; j++) {
			matrix[i][j] = new int[k];
		}
	}
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			for (int l = 0; l < k; l++)
				matrix[i][j][k - (l + 1)] = bmp.data[i * m * k + j * k + l];
	return matrix;
}

void BMPset(const char* fname, int32_t width, int32_t heigth, int*** matrix) {
	BMP bmp(width, heigth, false);
	for (int i = 0; i < heigth; i++)
		for (int j = 0; j < width; j++) {
			bmp.set_pixel(j, i, matrix[i][j][0], matrix[i][j][1], matrix[i][j][2], 0);
		}
	bmp.write(fname);
}

int*** Max_poolingx2(int*** img, int& w, int& h) {
	w = w / 2;
	h = h / 2;
	int*** pooled_img = new int** [h];
	for (int i = 0; i < h; i++) {
		pooled_img[i] = new int* [w];
		for (int j = 0; j < w; j++)
			pooled_img[i][j] = new int[3];
	}
	for (int y = 0; y < h; ++y) {
		for (int x = 0; x < w; ++x) {
			for (int i = 0; i < 2; ++i) {
				for (int j = 0; j < 2; ++j) {
					for (int c = 0; c < 3; ++c) {
						int value = img[y * 2 + i][x * 2 + j][c];
						pooled_img[y][x][c] = max(pooled_img[y][x][c], value);
					}
				}
			}
		}
	}
	return pooled_img;
}

int** toMono(int*** img, int w, int h) {
	int** Mono = new int* [h];
	for (int i = 0; i < h; i++)
		Mono[i] = new int[w];
	for (int i = 0; i < h; i++) 
		for (int j = 0; j < w; j++) {
			int* pix = new int[3];
			for (int k = 0; k < 3; k++)
				pix[k] = img[i][j][k];
			Mono[i][j] = (0.2125 * pix[0]) + (0.7154 * pix[1]) + (0.0721 * pix[2]);
			delete[] pix;
		}
	return Mono;
}

int*** toRGB(int** mono, int w, int h) {
	int*** RGB = new int** [h];
	for (int i = 0; i < h; i++) {
		RGB[i] = new int* [w];
		for (int j = 0; j < w; j++) {
			RGB[i][j] = new int[3];
			for (int k = 0; k < 3; k++)
				RGB[i][j][k] = mono[i][j];
		}
	}
	return RGB;
}

int*** padding(int*** img_orig, int w, int h, int pad_n) {
	// Creating a matrix of an image after padding
	int h_padded = h + (pad_n * 2);
	int w_padded = w + (pad_n * 2);
	int*** img_padded = new int** [h_padded];
	for (int i = 0; i < h_padded; i++) {
		img_padded[i] = new int* [w_padded];
		for (int j = 0; j < w_padded; j++)
			img_padded[i][j] = new int[3];
	}

	for (int i = 0; i < h; i++)
		for (int j = 0; j < w; j++)
			for (int k = 0; k < 3; k++)
				img_padded[i+pad_n][j+pad_n][k] = img_orig[i][j][k];

	for (int i = 0; i < h_padded; i++)
		for (int j = 0; j < w_padded; j++)
		{
			if ((i < pad_n || j < pad_n) || (i > h + pad_n - 1 || j > w + pad_n - 1)) {
				int x = i;
				int y = j;
				if (i < pad_n)
					x = pad_n;
				else if (i > h + pad_n - 1)
					x = h + pad_n - 1;
				if (j < pad_n)
					y = pad_n;
				else if (j > w + pad_n - 1)
					y = w + pad_n - 1;
				for (int k = 0; k < 3; k++)
					img_padded[i][j][k] = img_orig[x - pad_n][y - pad_n][k];
			}
		}

	//w = w_padded;
	//h = h_padded;
	return img_padded;
}

int** mono_padding(int** img_orig, int w, int h, int pad_n) {
	// Creating a matrix of an image after padding
	int h_padded = h + (pad_n * 2);
	int w_padded = w + (pad_n * 2);
	int** img_padded = new int* [h_padded];
	for (int i = 0; i < h_padded; i++) 
		img_padded[i] = new int [w_padded];

	for (int i = 0; i < h; i++)
		for (int j = 0; j < w; j++)
			img_padded[i + pad_n][j + pad_n] = img_orig[i][j];

	for (int i = 0; i < h_padded; i++)
		for (int j = 0; j < w_padded; j++)
		{
			if ((i < pad_n || j < pad_n) || (i > h + pad_n - 1 || j > w + pad_n - 1)) {
				int x = i;
				int y = j;
				if (i < pad_n)
					x = pad_n;
				else if (i > h + pad_n - 1)
					x = h + pad_n - 1;
				if (j < pad_n)
					y = pad_n;
				else if (j > w + pad_n - 1)
					y = w + pad_n - 1;
				img_padded[i][j] = img_orig[x - pad_n][y - pad_n];
			}
		}

	//w = w_padded;
	//h = h_padded;
	return img_padded;
}

int*** Conv3x3(int*** img, int width, int heigth, int Kernel[3][3], int div = 1) {
	int*** img_to_conv = padding(img, width, heigth, 1);
	int*** img_conved = new int** [heigth];
	for (int i = 0; i < heigth; i++) {
		img_conved[i] = new int* [width];
		for (int j = 0; j < width; j++) {
			//cout << "Point at " << i << " " << j << "..." << endl;
			img_conved[i][j] = new int[3];
			int* buf = new int[3];
			for (int k = 0; k < 3; k++) {
				long int sum = 0;
				for (int l = 0; l < 3; l++)
					for (int g = 0; g < 3; g++) {
						sum += img_to_conv[i + l][j + g][k] * Kernel[l][g];
					}
				buf[k] = sum / div;
			}
			for (int k = 0; k < 3; k++) {
				if (buf[k] > 255)
					buf[k] = 255;
				if (buf[k] < 0)
					buf[k] = 0;
				img_conved[i][j][k] = buf[k];
			}
			delete[] buf;
		}
	}
	return img_conved;
}

int*** Conv5x5(int*** img, int width, int heigth, int Kernel[5][5], int div = 1) {
	int*** img_to_conv = padding(img, width, heigth, 2);
	int*** img_conved = new int** [heigth];
	for (int i = 0; i < heigth; i++) {
		img_conved[i] = new int* [width];
		for (int j = 0; j < width; j++) {
			//cout << "Point at " << i << " " << j << "..." << endl;
			img_conved[i][j] = new int[3];
			int* buf = new int[3];
			for (int k = 0; k < 3; k++) {
				long int sum = 0;
				for (int l = 0; l < 5; l++)
					for (int g = 0; g < 5; g++) {
						sum += img_to_conv[i + l][j + g][k] * Kernel[l][g];
					}
				buf[k] = sum / div;
			}
			for (int k = 0; k < 3; k++) {
				if (buf[k] > 255)
					buf[k] = 255;
				if (buf[k] < 0)
					buf[k] = 0;
				img_conved[i][j][k] = buf[k];
			}
			delete[] buf;
		}
	}
	return img_conved;
}

int** Conv3x3_mono(int** mono_img, int width, int heigth, int Kernel[3][3]) {
	int** img_to_conv = mono_padding(mono_img, width, heigth, 1);
	int** img_conved = new int* [heigth];
	for (int i = 0; i < heigth; i++) {
		img_conved[i] = new int [width];
		for (int j = 0; j < width; j++) {
			//cout << "Point at " << i << " " << j << "..." << endl;
			int sum = 0;
			for (int l = 0; l < 3; l++)
				for (int g = 0; g < 3; g++) 
					sum += img_to_conv[i + l][j + g] * Kernel[l][g];
			if (sum > 255)
				sum = 255;
			if (sum < 0)
				sum = 0;
			img_conved[i][j] = sum;
		}
	}
	return img_conved;
}

int** Threshold(int** monoImg, int imgW, int imgH, int Step = 127) {
	int** imgT = new int* [imgH];
	for (int i = 0; i < imgH; i++)
		imgT[i] = new int[imgW];
	for (int i = 0; i < imgH; i++)
		for (int j = 0; j < imgW; j++)
			if (monoImg[i][j] > Step)
				imgT[i][j] = 255;
			else
				imgT[i][j] = 0;
	return imgT;
}

struct Canny {

	void edge(int*** img, int w, int h, int t_l = 95, int t_h = 150) {
		int Gauss_k[5][5] = {
			{2, 4, 5, 4, 2},
			{4, 9, 12, 9, 4},
			{5, 12, 15, 12, 5},
			{4, 9, 12, 9, 4},
			{2, 4, 5, 4, 2},
		};

		// blur & Sobel step

		int*** img_1 = Conv5x5(img, w, h, Gauss_k, 159);
		int*** img_ = Conv3_sobel_mono(img_1, w, h);

		//gradient vector check

		for (int i = 0; i < h; i++) {
			for (int j = 0; j < w; j++) {
				//cout << img_[i][j][1] << ", ";
				if (i > 0 && i < h - 1 && j > 0 && j < w - 1) {
					int x1, y1, x2, y2;
					x1 = x2 = y1 = y2 = 0;
					if (img_[i][j][1] == 0) {
						y1 = y2 = j;
						x1 = i + 1;
						x2 = i - 1;
					}
					else if (img_[i][j][1] == 45) {
						x1 = i + 1;
						y1 = j - 1;
						x2 = i - 1;
						y2 = j + 1;
					}
					else if (img_[i][j][1] == 90) {
						x1 = x2 = i;
						y1 = j + 1;
						y2 = j - 1;
					}
					else if (img_[i][j][1] == 135) {
						x1 = i + 1;
						y1 = j + 1;
						x2 = i - 1;
						y2 = j - 1;
					}
					if (img_[i][j][0] < img_[x1][y1][0] || img_[i][j][0] < img_[x2][y2][0]) {
						img_[i][j][2] = -3;
						img_[i][j][0] = 0;
					}

				}
				else {
					img_[i][j][0] = 0;
					img_[i][j][2] = -3;
				}

				//threshold check

				if (img_[i][j][0] >= t_h)
					img_[i][j][0] = 255;
				else if (img_[i][j][0] <= t_l) {
					img_[i][j][0] = 0;
					img_[i][j][2] = -3;
				}
				else
					img_[i][j][0] = 127; {
					img_[i][j][2] = -3;
				}
				
			}
			//cout << "\n";
		}
		
		// weak edge check

		bool flag = true;
		while (flag) {
			flag = false;
			for(int i = 1; i < h-1; i++)
				for(int j = 1; j < w-1; j++)
					if (img_[i][j][0] == 127) {
						bool f1 = false;
						for(int x = -1; x < 2; x++)
							for(int y = -1; y < 2; y++)
								if (img_[i + x][j + y][0] == 255) {
									f1 = true;
								}
						if (f1) {
							flag = true;
							img_[i][j][0] = 255;
							img_[i][j][2] = 0;
						}
					}
		}
		for (int i = 1; i < h - 1; i++)
			for (int j = 1; j < w - 1; j++)
				if (img_[i][j][0] == 255) {
					bool f1 = false;
					int count = -1;
					for (int x = -1; x < 2; x++)
						for (int y = -1; y < 2; y++)
							if (img_[i + x][j + y][0] == 255) {
								f1 = true;
								count++;
							}
					if (f1) {
						if (count == 0) {
							img_[i][j][0] = 0;
							img_[i][j][2] = -3;
						}
						else if (count < 2) {
							img_[i][j][2] = count;
							img_[i][j][3] = 1;
							img_[i][j][0] = 126;
						}
					}
				}
		/*
		flag = true;
		while (flag) {
			flag = false;
			for(int i = 1; i < h-1; i++)
				for(int j = 1; j < w-1; j++)
					if (img_[i][j][3] != 1 && img_[i][j][0] == 255) {
						flag = true;
						bool maince = false;
						for(int x = -1; x < 2; x++)
							for(int y = -1; y < 2; y++)
								if (x != 0 && y != 0)
									if (img_[i + x][j + y][3] == 1)
										maince = true;
						if (maince) {
							img_[i][j][3] = 1;
						}
						else {
							img_[i][j][0] = 0;
							img_[i][j][2] = -3;
						}
					}
		}
		*/
		// filtering trash edges & converting in the right format
		int** img_mono = new int* [h];
		for (int i = 0; i < h; i++) {
			img_mono[i] = new int[w];
			for (int j = 0; j < w; j++)
				if (img_[i][j][0] == 255)
					img_mono[i][j] = 255;
				else if (img_[i][j][0] == 126)
					img_mono[i][j] = 126;
				else
					img_mono[i][j] = 0;
		}
		//saving or returning the result

		BMPset("result.bmp", w, h, toRGB(img_mono, w, h));
	}

private:
	void edgeSobel3(int part[3][3], int& G, int& vec_) {
		int Kx[3][3] = {
			{-1, 0, 1},
			{-2, 0, 2},
			{-1, 0, 1} };
		int Ky[3][3] = {
			{1, 2, 1},
			{0, 0, 0},
			{-1, -2, -1} };
		int out[2] = { 0, 0 };
		int Gx = 0;
		int Gy = 0;
		for (int l = 0; l < 3; l++)
			for (int g = 0; g < 3; g++) {
				Gx += part[l][g] * Kx[l][g];
				Gy += part[l][g] * Ky[l][g];
			}
		G = sqrt(Gx * Gx + Gy * Gy);
		int vec = round(atan2(Gx, Gy) * 180 / 3.1415926 / 45) * 45;
		if (vec == 180)
			vec = 0;
		else if (vec == -45)
			vec = 135;
		else if (vec == -90)
			vec = 90;
		else if (vec == -135)
			vec = 45;
		vec_ = vec;
	}

	int*** padding(int*** img_orig, int w, int h, int pad_n) {
		// Creating a matrix of an image after padding
		int h_padded = h + (pad_n * 2);
		int w_padded = w + (pad_n * 2);
		int*** img_padded = new int** [h_padded];
		for (int i = 0; i < h_padded; i++) {
			img_padded[i] = new int* [w_padded];
			for (int j = 0; j < w_padded; j++)
				img_padded[i][j] = new int[3];
		}

		for (int i = 0; i < h; i++)
			for (int j = 0; j < w; j++)
				for (int k = 0; k < 3; k++)
					img_padded[i + pad_n][j + pad_n][k] = img_orig[i][j][k];

		for (int i = 0; i < h_padded; i++)
			for (int j = 0; j < w_padded; j++)	
			{
				if ((i < pad_n || j < pad_n) || (i > h + pad_n - 1 || j > w + pad_n - 1)) {
					int x = i;
					int y = j;
					if (i < pad_n)
						x = pad_n;
					else if (i > h + pad_n - 1)
						x = h + pad_n - 1;
					if (j < pad_n)
						y = pad_n;
					else if (j > w + pad_n - 1)
						y = w + pad_n - 1;
					for (int k = 0; k < 3; k++)
						img_padded[i][j][k] = img_orig[x - pad_n][y - pad_n][k];
				}
			}

		//w = w_padded;
		//h = h_padded;
		return img_padded;
	}

	int*** padding_Canny(int*** img_orig, int w, int h, int pad_n = 1) {
		// Creating a matrix of an image after padding
		int h_padded = h + (pad_n * 2);
		int w_padded = w + (pad_n * 2);
		int*** img_padded = new int** [h_padded];
		for (int i = 0; i < h_padded; i++) {
			img_padded[i] = new int* [w_padded];
			for (int j = 0; j < w_padded; j++)
				img_padded[i][j] = new int[2];
		}

		for (int i = 0; i < h; i++)
			for (int j = 0; j < w; j++) {
				img_padded[i + pad_n][j + pad_n][0] = img_orig[i][j][0];
				img_padded[i + pad_n][j + pad_n][1] = img_orig[i][j][1];
			}

		for (int i = 0; i < h_padded; i++)
			for (int j = 0; j < w_padded; j++)
			{
				if ((i < pad_n || j < pad_n) || (i > h + pad_n - 1 || j > w + pad_n - 1)) {
					int x = i;
					int y = j;
					if (i < pad_n)
						x = pad_n;
					else if (i > h + pad_n - 1)
						x = h + pad_n - 1;
					if (j < pad_n)
						y = pad_n;
					else if (j > w + pad_n - 1)
						y = w + pad_n - 1;
					for (int k = 0; k < 3; k++)
						img_padded[i][j][0] = img_orig[x - pad_n][y - pad_n][0];
				}
			}
		
		//w = w_padded;
		//h = h_padded;
		return img_padded;
	}

	int*** Conv3_sobel_mono(int*** img, int width, int heigth, int pad_n = 1) {
		int*** img_to_conv = padding(img, width, heigth, pad_n);
		int*** img_conved = new int** [heigth];
		for (int i = 0; i < heigth; i++) {
			img_conved[i] = new int* [width];
			for (int j = 0; j < width; j++) {
				img_conved[i][j] = new int[4];
				//cout << "Point at " << i << " " << j << "..." << endl;
				int krl[3][3];
				for (int l = 0; l < 3; l++)
					for (int g = 0; g < 3; g++)
						krl[l][g] = mono_pix(img_to_conv[i + l][j + g]);
				edgeSobel3(krl, img_conved[i][j][0], img_conved[i][j][1]);
				img_conved[i][j][2] = 0;
				img_conved[i][j][3] = 0;
			}
		}
		return img_conved;
	}

	int*** Conv5x5(int*** img, int width, int heigth, int Kernel[5][5], int div = 1, int channel = 3) {
		int*** img_to_conv = padding(img, width, heigth, 2);
		int*** img_conved = new int** [heigth];
		for (int i = 0; i < heigth; i++) {
			img_conved[i] = new int* [width];
			for (int j = 0; j < width; j++) {
				//cout << "Point at " << i << " " << j << "..." << endl;
				img_conved[i][j] = new int[channel];
				int* buf = new int[channel];
				for (int k = 0; k < channel; k++) {
					long int sum = 0;
					for (int l = 0; l < 5; l++)
						for (int g = 0; g < 5; g++) {
							sum += img_to_conv[i + l][j + g][k] * Kernel[l][g];
						}
					buf[k] = sum / div;
				}
				for (int k = 0; k < 3; k++) {
					if (buf[k] > 255)
						buf[k] = 255;
					if (buf[k] < 0)
						buf[k] = 0;
					img_conved[i][j][k] = buf[k];
				}
				delete[] buf;
			}
		}
		return img_conved;
	}
	int** Conv5x5_mono(int*** img, int width, int heigth, int Kernel[5][5], int div = 1) {
		int*** img_to_conv = padding(img, width, heigth, 2);
		int** img_conved = new int* [heigth];
		for (int i = 0; i < heigth; i++) {
			img_conved[i] = new int [width];
			for (int j = 0; j < width; j++) {
				//cout << "Point at " << i << " " << j << "..." << endl;
					long int sum = 0;
					for (int l = 0; l < 5; l++)
						for (int g = 0; g < 5; g++) {
							sum += mono_pix(img_to_conv[i + l][j + g]) * Kernel[l][g];
						}
					sum = sum / div;
					if (sum > 255)
						sum = 255;
					else if (sum < 0)
						sum = 0;
					img_conved[i][j] = sum;
			}
		}
		return img_conved;
	}

	int*** toRGB(int** mono, int w, int h) {
		int*** RGB = new int** [h];
		for (int i = 0; i < h; i++) {
			RGB[i] = new int* [w];
			for (int j = 0; j < w; j++) {
				RGB[i][j] = new int[3];
				for (int k = 0; k < 3; k++)
					RGB[i][j][k] = mono[i][j];
			}
		}
		return RGB;
	}
};

int main()
{
	Canny edge;
	int32_t w = 0;
	int32_t h = 0;
	int*** img = BMPread("threshold.bmp", w, h);
	edge.edge(img, w, h, 120, 190);
}
